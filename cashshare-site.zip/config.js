// Configuration Supabase de CashShare.
// La clé « publishable » est faite pour être publique : la sécurité repose sur les règles de la base.
// N'inscrivez JAMAIS ici une clé « secret » ou « service_role ».
window.CASHSHARE = {
  SUPABASE_URL: "https://ihswhjtzxxjiqbmlhaiv.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_dkUcP-_CdzdO_m_Q_H1IKQ_45Ck-Ws6"
};
