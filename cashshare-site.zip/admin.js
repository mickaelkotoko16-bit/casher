(function () {
  'use strict';
  const app = $('#app');
  let section = 'overview';
  const filter = { deposits: 'pending', withdrawals: 'open', campaigns: 'pending_review' };
  let query = '';

  const SECTIONS = [['overview', 'Vue d’ensemble'], ['deposits', 'Dépôts'], ['withdrawals', 'Retraits'],
    ['campaigns', 'Campagnes'], ['users', 'Utilisateurs'], ['settings', 'Paramètres'],
    ['alerts', 'Notifications'], ['log', 'Historique']];

  const SETTING_LABELS = {
    commission_percent: 'Commission de la plateforme (%)',
    price_per_view: 'Prix facturé par vue (FCFA)',
    price_per_click: 'Prix facturé par clic unique (FCFA)',
    min_campaign_budget: 'Budget minimum d’une campagne (FCFA)',
    min_withdrawal: 'Retrait minimum (FCFA)',
    deposit_phone: 'Numéro de réception mobile money',
    referral_reward: 'Récompense de parrainage (FCFA)'
  };

  async function boot() {
    if (!cfgOk) return configMissing(app);
    const s = await sb.auth.getSession();
    if (!s.data.session) return login();
    gate();
  }

  function login() {
    app.innerHTML = '<div class="brand">Administration</div><form id="f" class="card stack">' +
      '<div><label>Adresse e-mail</label><input name="email" type="email" required autocomplete="email"></div>' +
      '<div><label>Mot de passe</label><input name="password" type="password" required autocomplete="current-password"></div>' +
      '<button class="full" type="submit">Connexion privée</button></form>';
    $('#f').onsubmit = function (ev) {
      ev.preventDefault();
      const f = new FormData(ev.target);
      guard(ev.target.querySelector('button'), async function () {
        const r = await sb.auth.signInWithPassword({ email: String(f.get('email')).trim(), password: String(f.get('password')) });
        if (r.error) throw r.error;
        await gate();
      });
    };
  }

  async function gate() {
    const r = await sb.rpc('is_admin');
    if (r.error || !r.data) {
      app.innerHTML = '<div class="card"><h1>Accès refusé</h1><p>Ce compte n’a pas les droits d’administration.</p><button class="full" id="out">Se déconnecter</button></div>';
      $('#out').onclick = function () { sb.auth.signOut().then(login); };
      return;
    }
    render();
  }

  async function render() {
    app.innerHTML = '<p class="center muted" style="margin-top:40px">Chargement…</p>';
    try {
      const out = await views[section]();
      app.innerHTML = '<div class="top"><div class="brand">Administration</div><button class="ghost small" id="out">Quitter</button></div>' +
        '<div class="scroll">' + SECTIONS.map(function (s) { return '<button data-sec="' + s[0] + '" class="' + (s[0] === section ? 'on' : '') + '">' + s[1] + '</button>'; }).join('') + '</div>' +
        out.html;
      $('#out').onclick = function () { sb.auth.signOut().then(login); };
      app.querySelectorAll('[data-sec]').forEach(function (b) { b.onclick = function () { section = b.dataset.sec; render(); }; });
      if (out.bind) out.bind();
    } catch (e) {
      app.innerHTML = '<div class="card"><p>' + esc(errText(e)) + '</p><button class="full" id="retry">Réessayer</button></div>';
      $('#retry').onclick = render;
    }
  }

  function list(items, empty) {
    return items.length ? '<div class="card">' + items.join('') + '</div>' : '<p class="muted small">' + empty + '</p>';
  }
  function who(p) { return p ? esc(p.full_name) + ' · ' + esc(p.phone) : 'Utilisateur inconnu'; }
  function filterBox(key, options) {
    return '<select id="flt" style="margin-bottom:8px">' + options.map(function (o) {
      return '<option value="' + o[0] + '"' + (filter[key] === o[0] ? ' selected' : '') + '>' + o[1] + '</option>';
    }).join('') + '</select>';
  }
  function bindFilter(key) {
    $('#flt').onchange = function (e) { filter[key] = e.target.value; render(); };
  }
  function act(btn, name, params, okMsg) {
    guard(btn, async function () {
      const r = await sb.rpc(name, params);
      if (r.error) throw r.error;
      toast(okMsg);
      render();
    });
  }
  function ask(label, def) {
    const v = prompt(label, def == null ? '' : def);
    return v === null ? null : String(v).trim();
  }

  const views = {
    overview: async function () {
      const res = await Promise.all([
        sb.from('profiles').select('id', { count: 'exact', head: true }),
        sb.from('wallets').select('id', { count: 'exact', head: true }).eq('kind', 'advertiser'),
        sb.from('wallets').select('id', { count: 'exact', head: true }).eq('kind', 'broadcaster'),
        sb.from('campaigns').select('id', { count: 'exact', head: true }).eq('status', 'active'),
        sb.from('campaigns').select('id', { count: 'exact', head: true }).eq('status', 'pending_review'),
        sb.from('deposits').select('amount').eq('status', 'pending'),
        sb.from('withdrawals').select('amount').in('status', ['pending', 'verifying', 'approved']),
        sb.from('wallets').select('id').eq('kind', 'platform').single()
      ]);
      res.forEach(function (r) { if (r.error) throw r.error; });
      const rev = await sb.from('wallet_balances').select('balance').eq('wallet_id', res[7].data.id).eq('bucket', 'available');
      if (rev.error) throw rev.error;
      const sum = function (rows) { return (rows || []).reduce(function (a, x) { return a + Number(x.amount); }, 0); };
      const dep = res[5].data, wd = res[6].data;
      const revenue = (rev.data || []).reduce(function (a, x) { return a + Number(x.balance); }, 0);
      return {
        html: '<div class="grid2">' +
          '<div class="card"><div class="muted small">Utilisateurs</div><div class="kpi">' + res[0].count + '</div><div class="muted small">' + res[1].count + ' annonceurs · ' + res[2].count + ' diffuseurs</div></div>' +
          '<div class="card"><div class="muted small">Campagnes actives</div><div class="kpi">' + res[3].count + '</div></div>' +
          '<div class="card"><div class="muted small">Dépôts en attente</div><div class="kpi">' + dep.length + '</div><div class="muted small">' + fcfa(sum(dep)) + '</div></div>' +
          '<div class="card"><div class="muted small">Retraits en attente</div><div class="kpi">' + wd.length + '</div><div class="muted small">' + fcfa(sum(wd)) + '</div></div>' +
          '<div class="card"><div class="muted small">Montants en attente de validation</div><div class="kpi">' + fcfa(sum(dep) + sum(wd)) + '</div></div>' +
          '<div class="card"><div class="muted small">Revenus de la plateforme</div><div class="kpi">' + fcfa(revenue) + '</div></div></div>' +
          '<h2>À traiter</h2><div class="actions">' +
          '<button data-sec="deposits">Dépôts (' + dep.length + ')</button>' +
          '<button data-sec="withdrawals">Retraits (' + wd.length + ')</button>' +
          '<button data-sec="campaigns">Campagnes à valider (' + res[4].count + ')</button></div>'
      };
    },

    deposits: async function () {
      let q = sb.from('deposits').select('*, profiles(full_name,phone)').order('created_at', { ascending: false }).limit(60);
      if (filter.deposits !== 'all') q = q.eq('status', filter.deposits);
      const r = await q;
      if (r.error) throw r.error;
      return {
        html: '<h1>Dépôts</h1>' + filterBox('deposits', [['pending', 'En attente'], ['approved', 'Validés'], ['rejected', 'Refusés'], ['all', 'Tous']]) +
          list(r.data.map(function (d) {
            return '<div class="item"><div class="row"><b>' + fcfa(d.amount) + '</b>' + badge(d.status) + '</div>' +
              '<div class="small">' + who(d.profiles) + '</div>' +
              '<div class="muted small">Déposé le ' + fdate(d.created_at) + (d.paid_at ? ' · Payé le ' + fdate(d.paid_at) : '') + (d.tx_reference ? ' · Réf. ' + esc(d.tx_reference) : '') + '</div>' +
              (d.confirmed_amount != null ? '<div class="small">Montant confirmé : ' + fcfa(d.confirmed_amount) + '</div>' : '') +
              (d.reject_reason ? '<div class="small">Motif : ' + esc(d.reject_reason) + '</div>' : '') +
              (d.status === 'pending' ? '<div class="actions"><button class="small" data-ok="' + d.id + '" data-amt="' + d.amount + '">Valider</button><button class="small danger" data-no="' + d.id + '">Refuser</button></div>' : '') + '</div>';
          }), 'Aucun dépôt dans cette catégorie.'),
        bind: function () {
          bindFilter('deposits');
          app.querySelectorAll('[data-ok]').forEach(function (b) {
            b.onclick = function () {
              const v = ask('Vérifiez d’abord le paiement dans votre application mobile money.\nMontant réellement reçu (FCFA) :', b.dataset.amt);
              if (v === null) return;
              const n = Number(v);
              if (!(n > 0)) return toast('Montant invalide.', true);
              act(b, 'approve_deposit', { p_deposit: b.dataset.ok, p_confirmed: n }, 'Dépôt validé et portefeuille crédité.');
            };
          });
          app.querySelectorAll('[data-no]').forEach(function (b) {
            b.onclick = function () {
              const v = ask('Motif du refus :');
              if (!v) return;
              act(b, 'reject_deposit', { p_deposit: b.dataset.no, p_reason: v }, 'Dépôt refusé.');
            };
          });
        }
      };
    },

    withdrawals: async function () {
      let q = sb.from('withdrawals').select('*, profiles(full_name,phone)').order('created_at', { ascending: false }).limit(60);
      if (filter.withdrawals === 'open') q = q.in('status', ['pending', 'verifying', 'approved']);
      else if (filter.withdrawals !== 'all') q = q.eq('status', filter.withdrawals);
      const r = await q;
      if (r.error) throw r.error;
      return {
        html: '<h1>Retraits</h1>' + filterBox('withdrawals', [['open', 'À traiter'], ['paid', 'Payés'], ['rejected', 'Refusés'], ['all', 'Tous']]) +
          list(r.data.map(function (w) {
            const open = ['pending', 'verifying', 'approved'].indexOf(w.status) >= 0;
            return '<div class="item"><div class="row"><b>' + fcfa(w.amount) + '</b>' + badge(w.status) + '</div>' +
              '<div class="small">' + who(w.profiles) + '</div>' +
              '<div class="small">À payer au : <b>' + esc(w.phone) + '</b></div>' +
              '<div class="muted small">Demandé le ' + fdate(w.created_at) + (w.payout_reference ? ' · Réf. ' + esc(w.payout_reference) : '') + '</div>' +
              (w.reject_reason ? '<div class="small">Motif : ' + esc(w.reject_reason) + '</div>' : '') +
              (open ? '<div class="actions">' +
                (w.status === 'pending' ? '<button class="ghost small" data-vf="' + w.id + '">En vérification</button>' : '') +
                (w.status !== 'approved' ? '<button class="ghost small" data-ap="' + w.id + '">Approuver</button>' : '') +
                '<button class="small" data-paid="' + w.id + '">Marquer payé</button><button class="small danger" data-no="' + w.id + '">Refuser</button></div>' : '') + '</div>';
          }), 'Aucun retrait dans cette catégorie.'),
        bind: function () {
          bindFilter('withdrawals');
          app.querySelectorAll('[data-vf]').forEach(function (b) { b.onclick = function () { act(b, 'set_withdrawal_status', { p_withdrawal: b.dataset.vf, p_status: 'verifying' }, 'Statut mis à jour.'); }; });
          app.querySelectorAll('[data-ap]').forEach(function (b) { b.onclick = function () { act(b, 'set_withdrawal_status', { p_withdrawal: b.dataset.ap, p_status: 'approved' }, 'Retrait approuvé.'); }; });
          app.querySelectorAll('[data-paid]').forEach(function (b) {
            b.onclick = function () {
              const v = ask('Effectuez d’abord le transfert mobile money.\nRéférence de la transaction :');
              if (!v) return;
              act(b, 'mark_withdrawal_paid', { p_withdrawal: b.dataset.paid, p_reference: v }, 'Retrait marqué comme payé.');
            };
          });
          app.querySelectorAll('[data-no]').forEach(function (b) {
            b.onclick = function () {
              const v = ask('Motif du refus (les fonds seront rendus au solde disponible) :');
              if (!v) return;
              act(b, 'reject_withdrawal', { p_withdrawal: b.dataset.no, p_reason: v }, 'Retrait refusé.');
            };
          });
        }
      };
    },

    campaigns: async function () {
      let q = sb.from('campaigns').select('*, profiles(full_name,phone,company_name)').order('created_at', { ascending: false }).limit(60);
      if (filter.campaigns !== 'all') q = q.eq('status', filter.campaigns);
      const r = await q;
      if (r.error) throw r.error;
      return {
        html: '<h1>Campagnes</h1>' + filterBox('campaigns', [['pending_review', 'À valider'], ['active', 'Actives'], ['paused', 'En pause'], ['rejected', 'Refusées'], ['all', 'Toutes']]) +
          list(r.data.map(function (c) {
            return '<div class="item"><div class="row"><b>' + esc(c.title) + '</b>' + badge(c.status) + '</div>' +
              '<div class="small">' + who(c.profiles) + (c.profiles && c.profiles.company_name ? ' · ' + esc(c.profiles.company_name) : '') + '</div>' +
              '<div class="small" style="margin-top:4px">' + esc(c.description) + '</div>' +
              '<div class="muted small">' + (c.goal === 'views' ? 'Vues' : 'Clics') + ' · ' + c.target_results + ' résultats · coût ' + fcfa(c.budget) +
              ' · récompenses ' + fcfa(c.reward_reserved) + ' · commission ' + fcfa(c.platform_fee) + '</div>' +
              (c.status === 'pending_review' ? '<div class="actions"><button class="small" data-ok="' + c.id + '">Approuver</button><button class="small danger" data-no="' + c.id + '">Refuser</button></div>' : '') + '</div>';
          }), 'Aucune campagne dans cette catégorie.'),
        bind: function () {
          bindFilter('campaigns');
          app.querySelectorAll('[data-ok]').forEach(function (b) { b.onclick = function () { act(b, 'set_campaign_status', { p_campaign: b.dataset.ok, p_status: 'active', p_reason: null }, 'Campagne approuvée.'); }; });
          app.querySelectorAll('[data-no]').forEach(function (b) {
            b.onclick = function () {
              const v = ask('Motif du refus (l’annonceur sera remboursé) :');
              if (!v) return;
              act(b, 'set_campaign_status', { p_campaign: b.dataset.no, p_status: 'rejected', p_reason: v }, 'Campagne refusée et annonceur remboursé.');
            };
          });
        }
      };
    },

    users: async function () {
      let q = sb.from('profiles').select('*').order('created_at', { ascending: false }).limit(30);
      const t = query.replace(/[,()%*]/g, ' ').trim();
      if (t) q = q.or('full_name.ilike.%' + t + '%,phone.ilike.%' + t + '%,id.eq.' + (/^[0-9a-f-]{36}$/i.test(t) ? t : '00000000-0000-0000-0000-000000000000'));
      const r = await q;
      if (r.error) throw r.error;
      return {
        html: '<h1>Utilisateurs</h1><form id="sf" class="row" style="margin-bottom:8px"><input name="q" placeholder="Nom, téléphone ou identifiant" value="' + esc(query) + '"><button type="submit">Chercher</button></form>' +
          list(r.data.map(function (p) {
            return '<div class="item"><div class="row"><b>' + esc(p.full_name) + '</b>' + badge(p.status) + '</div>' +
              '<div class="small">' + esc(p.phone) + (p.email ? ' · ' + esc(p.email) : '') + '</div>' +
              '<div class="muted small">' + (p.company_name ? esc(p.company_name) + ' · ' : '') + esc(p.age_range || '') + ' · inscrit le ' + fdate(p.created_at) + '</div>' +
              '<div class="muted small">ID : ' + esc(p.id) + '</div>' +
              '<div class="actions"><button class="small ' + (p.status === 'active' ? 'danger' : '') + '" data-st="' + p.id + '" data-to="' + (p.status === 'active' ? 'suspended' : 'active') + '">' + (p.status === 'active' ? 'Suspendre' : 'Réactiver') + '</button></div></div>';
          }), 'Aucun utilisateur trouvé.'),
        bind: function () {
          $('#sf').onsubmit = function (e) { e.preventDefault(); query = String(new FormData(e.target).get('q') || ''); render(); };
          app.querySelectorAll('[data-st]').forEach(function (b) {
            b.onclick = function () {
              if (!confirm(b.dataset.to === 'suspended' ? 'Suspendre ce compte ?' : 'Réactiver ce compte ?')) return;
              act(b, 'set_user_status', { p_user: b.dataset.st, p_status: b.dataset.to }, 'Compte mis à jour.');
            };
          });
        }
      };
    },

    settings: async function () {
      const s = await loadSettings();
      return {
        html: '<h1>Paramètres</h1><p class="note">Ces valeurs s’appliquent immédiatement aux nouvelles opérations. Chaque modification est enregistrée dans l’historique.</p>' +
          '<div class="card stack">' + Object.keys(SETTING_LABELS).map(function (k) {
            const isText = k === 'deposit_phone';
            return '<div><label>' + SETTING_LABELS[k] + '</label><div class="row"><input data-key="' + k + '" ' + (isText ? 'type="tel"' : 'type="number" step="any" min="0"') + ' value="' + esc(s[k]) + '"><button class="small" data-save="' + k + '">Enregistrer</button></div></div>';
          }).join('') + '</div>',
        bind: function () {
          app.querySelectorAll('[data-save]').forEach(function (b) {
            b.onclick = function () {
              const k = b.dataset.save;
              const raw = app.querySelector('input[data-key="' + k + '"]').value.trim();
              let val;
              if (k === 'deposit_phone') val = raw;
              else { if (raw === '' || isNaN(Number(raw))) return toast('Valeur numérique attendue.', true); val = Number(raw); }
              act(b, 'set_setting', { p_key: k, p_value: val }, 'Paramètre enregistré.');
            };
          });
        }
      };
    },

    alerts: async function () {
      const r = await sb.from('notifications').select('*').is('user_id', null).order('created_at', { ascending: false }).limit(50);
      if (r.error) throw r.error;
      const unread = r.data.some(function (x) { return !x.read; });
      return {
        html: '<h1>Notifications</h1>' + list(r.data.map(function (n) {
          return '<div class="item"><div class="row"><b>' + esc(n.title) + '</b>' + (n.read ? '' : '<span class="badge">Nouveau</span>') + '</div><div class="small">' + esc(n.body) + '</div><div class="muted small">' + fdate(n.created_at) + '</div></div>';
        }), 'Aucune notification.'),
        bind: function () {
          if (unread) sb.from('notifications').update({ read: true }).is('user_id', null).eq('read', false).then(function () {});
        }
      };
    },

    log: async function () {
      const r = await sb.from('admin_actions').select('*').order('created_at', { ascending: false }).limit(100);
      if (r.error) throw r.error;
      return {
        html: '<h1>Historique des actions</h1>' + list(r.data.map(function (a) {
          return '<div class="item"><b>' + esc(a.action) + '</b><div class="small">' + esc(a.details || '') + '</div><div class="muted small">' + fdate(a.created_at) + (a.target_id ? ' · ' + esc(a.target_table) + ' ' + esc(a.target_id) : '') + '</div></div>';
        }), 'Aucune action enregistrée.')
      };
    }
  };

  boot();
})();
