(function () {
  'use strict';
  const c = window.CASHSHARE || {};
  window.cfgOk = !!(c.SUPABASE_URL && c.SUPABASE_ANON_KEY && !/VOTRE/.test(c.SUPABASE_URL) && !/VOTRE/.test(c.SUPABASE_ANON_KEY));
  window.sb = window.cfgOk && window.supabase
    ? window.supabase.createClient(c.SUPABASE_URL, c.SUPABASE_ANON_KEY)
    : null;

  window.$ = function (sel) { return document.querySelector(sel); };

  window.esc = function (s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (ch) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch];
    });
  };

  window.fcfa = function (n) {
    return new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 2 }).format(Number(n) || 0) + ' FCFA';
  };

  window.fdate = function (d) {
    return d ? new Date(d).toLocaleString('fr-FR', { dateStyle: 'medium', timeStyle: 'short' }) : '';
  };

  const STATUS = {
    pending: ['En attente', 'warn'], verifying: ['En cours de vérification', 'warn'],
    approved: ['Approuvé', 'ok'], paid: ['Payé', 'ok'], rejected: ['Refusé', 'bad'],
    pending_review: ['En validation', 'warn'], active: ['Active', 'ok'], paused: ['En pause', ''],
    completed: ['Terminée', ''], suspended: ['Suspendu', 'bad'], needs_new_proof: ['Nouvelle preuve demandée', 'warn']
  };
  window.badge = function (s) {
    const x = STATUS[s] || [s, ''];
    return '<span class="badge ' + x[1] + '">' + esc(x[0]) + '</span>';
  };

  let tt;
  window.toast = function (msg, isErr) {
    let el = $('#toast');
    if (!el) { el = document.createElement('div'); el.id = 'toast'; document.body.appendChild(el); }
    el.textContent = msg;
    el.className = isErr ? 'err' : '';
    el.style.display = 'block';
    clearTimeout(tt);
    tt = setTimeout(function () { el.style.display = 'none'; }, 4500);
  };

  window.errText = function (e) {
    const m = (e && e.message) || String(e);
    if (/duplicate key|unique/i.test(m)) {
      if (/phone/i.test(m)) return 'Ce numéro de téléphone est déjà utilisé.';
      if (/txref/i.test(m)) return 'Cette référence de transaction a déjà été utilisée.';
      if (/hash/i.test(m)) return 'Cette preuve a déjà été utilisée.';
      return 'Cette information existe déjà.';
    }
    if (/Invalid login/i.test(m)) return 'E-mail ou mot de passe incorrect.';
    if (/Email not confirmed/i.test(m)) return 'Veuillez d’abord confirmer votre e-mail.';
    if (/already registered/i.test(m)) return 'Un compte existe déjà avec cet e-mail.';
    if (/row-level security/i.test(m)) return 'Action non autorisée.';
    return m;
  };

  window.guard = async function (btn, fn) {
    if (btn) btn.disabled = true;
    try { await fn(); } catch (e) { toast(errText(e), true); }
    finally { if (btn) btn.disabled = false; }
  };

  window.loadSettings = async function () {
    const r = await sb.from('settings').select('key,value');
    if (r.error) throw r.error;
    const s = {};
    (r.data || []).forEach(function (x) { s[x.key] = x.value; });
    return s;
  };

  window.configMissing = function (el) {
    el.innerHTML = '<div class="card"><h1>Configuration requise</h1>' +
      '<p>Ouvrez le fichier <b>config.js</b> et renseignez l’adresse de votre projet Supabase ainsi que la clé « anon ».</p></div>';
  };
})();
