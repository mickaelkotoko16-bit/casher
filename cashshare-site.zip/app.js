(function () {
  'use strict';
  const app = $('#app');
  let user = null, profile = null, W = {}, S = {};
  let space = 'advertiser', tab = 'home';

  const AGES = ['18–24 ans', '25–34 ans', '35–44 ans', '45 ans et plus'];

  /* ---------- Démarrage ---------- */
  async function boot() {
    if (!cfgOk) return configMissing(app);
    sb.auth.onAuthStateChange(function (ev) {
      if (ev === 'PASSWORD_RECOVERY') renderNewPassword();
      if (ev === 'SIGNED_OUT') { user = null; renderAuth('login'); }
    });
    const r = await sb.auth.getSession();
    if (r.data.session) await enter(r.data.session.user); else renderAuth('login');
  }

  async function enter(u) {
    user = u;
    app.innerHTML = '<p class="center muted" style="margin-top:40px">Chargement…</p>';
    try {
      profile = await ensureProfile(u);
      if (profile.status === 'suspended') {
        app.innerHTML = '<div class="card"><h1>Compte suspendu</h1><p>Votre compte est suspendu. Contactez l’assistance.</p><button class="ghost full" id="out">Se déconnecter</button></div>';
        $('#out').onclick = function () { sb.auth.signOut(); };
        return;
      }
      await loadWallets();
      const want = (u.user_metadata || {}).role;
      if (!W.advertiser && !W.broadcaster && (want === 'advertiser' || want === 'broadcaster')) await ensureRole(want);
      S = await loadSettings();
      space = W[space] ? space : (W.advertiser ? 'advertiser' : 'broadcaster');
      tab = 'home';
      render();
    } catch (e) {
      toast(errText(e), true);
      await sb.auth.signOut();
    }
  }

  async function ensureProfile(u) {
    const r = await sb.from('profiles').select('*').eq('id', u.id).maybeSingle();
    if (r.error) throw r.error;
    if (r.data) return r.data;
    const m = u.user_metadata || {};
    const ins = await sb.from('profiles').insert({
      id: u.id, full_name: m.full_name, phone: m.phone, email: u.email,
      age_range: m.age_range || null, company_name: m.company_name || null
    }).select().single();
    if (ins.error) throw ins.error;
    return ins.data;
  }

  async function loadWallets() {
    const r = await sb.from('wallets').select('id,kind').eq('user_id', user.id);
    if (r.error) throw r.error;
    W = {};
    (r.data || []).forEach(function (w) { W[w.kind] = w.id; });
  }

  async function ensureRole(kind) {
    if (W[kind]) return;
    const r = await sb.from('wallets').insert({ user_id: user.id, kind: kind });
    if (r.error) throw r.error;
    await loadWallets();
  }

  async function balances(kind) {
    const r = await sb.from('wallet_balances').select('bucket,balance').eq('wallet_id', W[kind]);
    if (r.error) throw r.error;
    const b = { available: 0, reserved: 0, pending: 0, withdrawing: 0 };
    (r.data || []).forEach(function (x) { b[x.bucket] = Number(x.balance); });
    return b;
  }

  /* ---------- Authentification ---------- */
  function renderAuth(mode) {
    if (!cfgOk) return configMissing(app);
    const signup = mode === 'signup';
    app.innerHTML =
      '<div class="brand">CashShare</div>' +
      '<p class="muted center">Faites connaître vos offres, ou diffusez des publicités et gagnez des revenus.</p>' +
      '<div class="seg"><button data-m="login" class="' + (!signup ? 'on' : '') + '">Connexion</button>' +
      '<button data-m="signup" class="' + (signup ? 'on' : '') + '">Inscription</button></div>' +
      '<form id="f" class="card stack">' +
      (signup
        ? '<div><label>Nom et prénom</label><input name="full_name" required autocomplete="name"></div>' +
          '<div><label>Numéro de téléphone</label><input name="phone" type="tel" required autocomplete="tel" placeholder="+225…"></div>'
        : '') +
      '<div><label>Adresse e-mail</label><input name="email" type="email" required autocomplete="email"></div>' +
      '<div><label>Mot de passe</label><input name="password" type="password" required minlength="8" autocomplete="' + (signup ? 'new-password' : 'current-password') + '"></div>' +
      (signup
        ? '<div><label>Tranche d’âge</label><select name="age_range" required>' + AGES.map(function (a) { return '<option>' + a + '</option>'; }).join('') + '</select></div>' +
          '<div><label>Je souhaite commencer en tant que</label><select name="role"><option value="broadcaster">Diffuseur (je partage des publicités)</option><option value="advertiser">Annonceur (je promeus mon activité)</option></select></div>' +
          '<div><label>Entreprise ou marque (facultatif)</label><input name="company_name"></div>' +
          '<label style="display:flex;gap:8px;align-items:flex-start"><input type="checkbox" name="terms" required style="width:auto;margin-top:3px"> J’accepte les conditions d’utilisation et la politique de confidentialité.</label>'
        : '') +
      '<button class="full" type="submit">' + (signup ? 'Créer mon compte' : 'Se connecter') + '</button>' +
      (signup ? '' : '<button type="button" class="ghost full" id="forgot">Mot de passe oublié</button>') +
      '</form>' +
      (signup ? '<p class="muted small center">Réservé aux personnes majeures. Vos informations ne sont jamais visibles par les autres utilisateurs.</p>' : '');

    app.querySelectorAll('.seg button').forEach(function (b) { b.onclick = function () { renderAuth(b.dataset.m); }; });

    $('#f').onsubmit = function (ev) {
      ev.preventDefault();
      const f = new FormData(ev.target);
      const btn = ev.target.querySelector('button[type=submit]');
      guard(btn, async function () {
        const email = String(f.get('email')).trim();
        const password = String(f.get('password'));
        if (!signup) {
          const r = await sb.auth.signInWithPassword({ email: email, password: password });
          if (r.error) throw r.error;
          await enter(r.data.user);
          return;
        }
        const phone = String(f.get('phone')).replace(/[\s.\-]/g, '');
        if (!/^\+?[0-9]{8,15}$/.test(phone)) throw new Error('Numéro de téléphone invalide.');
        const r = await sb.auth.signUp({
          email: email, password: password,
          options: {
            emailRedirectTo: location.origin + location.pathname,
            data: {
              full_name: String(f.get('full_name')).trim(), phone: phone, age_range: f.get('age_range'),
              role: f.get('role'), company_name: String(f.get('company_name') || '').trim()
            }
          }
        });
        if (r.error) throw r.error;
        if (r.data.session) { await enter(r.data.session.user); return; }
        app.innerHTML = '<div class="card"><h1>Vérifiez votre e-mail</h1><p>Un message de confirmation vient d’être envoyé à <b>' + esc(email) + '</b>. Après confirmation, connectez-vous.</p><button class="full" id="back">Retour à la connexion</button></div>';
        $('#back').onclick = function () { renderAuth('login'); };
      });
    };

    const fg = $('#forgot');
    if (fg) fg.onclick = function () {
      const email = String(new FormData($('#f')).get('email') || '').trim();
      if (!email) return toast('Saisissez d’abord votre adresse e-mail.', true);
      guard(fg, async function () {
        const r = await sb.auth.resetPasswordForEmail(email, { redirectTo: location.origin + location.pathname });
        if (r.error) throw r.error;
        toast('Si un compte existe, un e-mail de récupération a été envoyé.');
      });
    };
  }

  function renderNewPassword() {
    app.innerHTML = '<div class="brand">CashShare</div><form id="f" class="card stack"><h1>Nouveau mot de passe</h1>' +
      '<div><label>Nouveau mot de passe</label><input name="p" type="password" minlength="8" required autocomplete="new-password"></div>' +
      '<button class="full" type="submit">Enregistrer</button></form>';
    $('#f').onsubmit = function (ev) {
      ev.preventDefault();
      const btn = ev.target.querySelector('button');
      guard(btn, async function () {
        const r = await sb.auth.updateUser({ password: new FormData(ev.target).get('p') });
        if (r.error) throw r.error;
        toast('Mot de passe mis à jour.');
        const s = await sb.auth.getSession();
        if (s.data.session) await enter(s.data.session.user);
      });
    };
  }

  /* ---------- Structure commune ---------- */
  function shell(inner) {
    const tabs = space === 'advertiser'
      ? [['home', 'Accueil'], ['deposit', 'Approvisionner'], ['campaigns', 'Campagnes'], ['alerts', 'Alertes']]
      : [['home', 'Accueil'], ['ads', 'Publicités'], ['withdraw', 'Retrait'], ['alerts', 'Alertes']];
    return '<div class="top"><div class="brand">CashShare</div><button class="ghost small" id="out">Quitter</button></div>' +
      '<div class="seg"><button data-s="advertiser" class="' + (space === 'advertiser' ? 'on' : '') + '">Annonceur' + (W.advertiser ? '' : ' +') + '</button>' +
      '<button data-s="broadcaster" class="' + (space === 'broadcaster' ? 'on' : '') + '">Diffuseur' + (W.broadcaster ? '' : ' +') + '</button></div>' +
      inner +
      '<div class="nav">' + tabs.map(function (t) { return '<button data-t="' + t[0] + '" class="' + (tab === t[0] ? 'on' : '') + '">' + t[1] + '</button>'; }).join('') + '</div>';
  }

  function bindShell() {
    $('#out').onclick = function () { sb.auth.signOut(); };
    app.querySelectorAll('.seg button[data-s]').forEach(function (b) {
      b.onclick = async function () {
        const k = b.dataset.s;
        if (!W[k]) {
          const label = k === 'advertiser' ? 'annonceur' : 'diffuseur';
          if (!confirm('Activer votre espace ' + label + ' ? Un portefeuille distinct sera créé.')) return;
          try { await ensureRole(k); } catch (e) { return toast(errText(e), true); }
        }
        space = k; tab = 'home'; render();
      };
    });
    app.querySelectorAll('.nav button').forEach(function (b) { b.onclick = function () { tab = b.dataset.t; render(); }; });
  }

  async function render() {
    app.innerHTML = '<p class="center muted" style="margin-top:40px">Chargement…</p>';
    try {
      S = await loadSettings();
      const fn = space === 'advertiser' ? advTabs[tab] : brTabs[tab];
      const html = await fn();
      app.innerHTML = shell(html.html);
      bindShell();
      if (html.bind) html.bind();
    } catch (e) {
      app.innerHTML = '<div class="card"><p>' + esc(errText(e)) + '</p><button class="full" id="retry">Réessayer</button></div>';
      $('#retry').onclick = render;
    }
  }

  function list(items, empty) {
    return items.length ? '<div class="card">' + items.join('') + '</div>' : '<p class="muted small">' + empty + '</p>';
  }

  /* ---------- Espace annonceur ---------- */
  const advTabs = {
    home: async function () {
      const b = await balances('advertiser');
      const c = await sb.from('campaigns').select('budget,status').eq('advertiser_id', user.id);
      if (c.error) throw c.error;
      const spent = (c.data || []).filter(function (x) { return x.status !== 'rejected'; }).reduce(function (a, x) { return a + Number(x.budget); }, 0);
      const d = await sb.from('deposits').select('amount,status,created_at').eq('user_id', user.id).order('created_at', { ascending: false }).limit(3);
      return {
        html: '<h1>Bonjour ' + esc((profile.full_name || '').split(' ')[0]) + '</h1>' +
          '<div class="card"><div class="muted small">Solde disponible</div><div class="kpi">' + fcfa(b.available) + '</div></div>' +
          '<div class="grid2"><div class="card"><div class="muted small">Réservé aux campagnes</div><div class="kpi">' + fcfa(b.reserved) + '</div></div>' +
          '<div class="card"><div class="muted small">Dépenses engagées</div><div class="kpi">' + fcfa(spent) + '</div></div></div>' +
          '<div class="actions"><button data-go="deposit">Approvisionner mon compte</button><button class="ghost" data-go="campaigns">Créer une campagne</button></div>' +
          '<h2>Derniers approvisionnements</h2>' +
          list((d.data || []).map(function (x) { return '<div class="item row"><div>' + fcfa(x.amount) + '<div class="muted small">' + fdate(x.created_at) + '</div></div>' + badge(x.status) + '</div>'; }), 'Aucun approvisionnement pour le moment.'),
        bind: function () { app.querySelectorAll('[data-go]').forEach(function (b) { b.onclick = function () { tab = b.dataset.go; render(); }; }); }
      };
    },

    deposit: async function () {
      const d = await sb.from('deposits').select('*').eq('user_id', user.id).order('created_at', { ascending: false }).limit(30);
      if (d.error) throw d.error;
      const phone = S.deposit_phone || '';
      return {
        html: '<h1>Approvisionner mon compte</h1>' +
          '<div class="card stack"><div class="note">1. Envoyez le montant par mobile money au numéro officiel ci-dessous.<br>2. Revenez ici et renseignez votre paiement.<br>3. Votre portefeuille est crédité après vérification par l’administration (aucun crédit automatique).</div>' +
          '<div><div class="muted small">Numéro officiel de réception</div><div class="kpi">' + (phone ? esc(phone) : 'Non disponible pour le moment') + '</div></div></div>' +
          '<form id="df" class="card stack"><h2 style="margin-top:0">J’ai effectué un paiement</h2>' +
          '<div><label>Montant envoyé (FCFA)</label><input name="amount" type="number" min="100" step="1" required></div>' +
          '<div><label>Référence de transaction (si disponible)</label><input name="ref" autocomplete="off"></div>' +
          '<div><label>Date et heure du paiement</label><input name="paid_at" type="datetime-local"></div>' +
          '<button class="full" type="submit"' + (phone ? '' : ' disabled') + '>Envoyer pour vérification</button></form>' +
          '<h2>Historique</h2>' +
          list(d.data.map(function (x) {
            return '<div class="item"><div class="row"><b>' + fcfa(x.amount) + '</b>' + badge(x.status) + '</div>' +
              '<div class="muted small">' + fdate(x.created_at) + (x.tx_reference ? ' · Réf. ' + esc(x.tx_reference) : '') + '</div>' +
              (x.status === 'rejected' && x.reject_reason ? '<div class="small">Motif : ' + esc(x.reject_reason) + '</div>' : '') + '</div>';
          }), 'Aucun approvisionnement.'),
        bind: function () {
          $('#df').onsubmit = function (ev) {
            ev.preventDefault();
            const f = new FormData(ev.target);
            guard(ev.target.querySelector('button'), async function () {
              const ref = String(f.get('ref') || '').trim();
              const pa = f.get('paid_at');
              const r = await sb.from('deposits').insert({
                user_id: user.id, amount: Number(f.get('amount')),
                tx_reference: ref || null, paid_at: pa ? new Date(pa).toISOString() : null
              });
              if (r.error) throw r.error;
              toast('Demande envoyée. Elle sera vérifiée par l’administration.');
              render();
            });
          };
        }
      };
    },

    campaigns: async function () {
      const c = await sb.from('campaigns').select('*').eq('advertiser_id', user.id).order('created_at', { ascending: false });
      if (c.error) throw c.error;
      return {
        html: '<h1>Mes campagnes</h1>' +
          '<details class="card"><summary><b>Nouvelle campagne</b></summary><form id="cf" class="stack" style="margin-top:12px">' +
          '<div><label>Titre</label><input name="title" required maxlength="80"></div>' +
          '<div><label>Description et conditions de participation</label><textarea name="description" required></textarea></div>' +
          '<div><label>Objectif</label><select name="goal"><option value="views">Vues (' + fcfa(S.price_per_view) + ' par vue)</option><option value="clicks">Clics uniques (' + fcfa(S.price_per_click) + ' par clic)</option></select></div>' +
          '<div><label>Budget total (minimum ' + fcfa(S.min_campaign_budget) + ')</label><input name="budget" type="number" min="' + Number(S.min_campaign_budget) + '" step="1" required></div>' +
          '<div class="note" id="pv">Saisissez un budget pour voir le détail.</div>' +
          '<button class="full" type="submit">Créer la campagne</button>' +
          '<p class="muted small">La campagne est vérifiée par l’administration avant d’être visible. Les images et vidéos seront ajoutées à l’étape suivante.</p></form></details>' +
          '<h2>Historique</h2>' +
          list(c.data.map(function (x) {
            const pct = Math.min(100, Math.round(100 * x.results_validated / x.target_results));
            return '<div class="item"><div class="row"><b>' + esc(x.title) + '</b>' + badge(x.status) + '</div>' +
              '<div class="muted small">' + (x.goal === 'views' ? 'Vues' : 'Clics') + ' · ' + x.results_validated + ' / ' + x.target_results + ' résultats validés · ' + fcfa(x.budget) + '</div>' +
              '<div class="bar"><i style="width:' + pct + '%"></i></div>' +
              ((x.status === 'active' || x.status === 'paused') ? '<div class="actions"><button class="ghost small" data-pause="' + x.id + '">' + (x.status === 'active' ? 'Mettre en pause' : 'Reprendre') + '</button></div>' : '') + '</div>';
          }), 'Vous n’avez pas encore de campagne.'),
        bind: function () {
          const form = $('#cf');
          function preview() {
            const f = new FormData(form);
            const goal = f.get('goal'), budget = Number(f.get('budget')) || 0;
            const price = Number(goal === 'views' ? S.price_per_view : S.price_per_click);
            const n = Math.floor(budget / price), cost = n * price;
            const fee = Math.round(cost * Number(S.commission_percent)) / 100;
            $('#pv').innerHTML = n < 1 ? 'Saisissez un budget pour voir le détail.' :
              'Résultats visés : <b>' + n + '</b><br>Budget destiné aux récompenses : <b>' + fcfa(cost - fee) + '</b><br>Frais de la plateforme : <b>' + fcfa(fee) + '</b><br>Coût total : <b>' + fcfa(cost) + '</b>';
          }
          form.addEventListener('input', preview);
          form.onsubmit = function (ev) {
            ev.preventDefault();
            const f = new FormData(form);
            guard(form.querySelector('button[type=submit]'), async function () {
              const r = await sb.rpc('create_campaign', {
                p_title: String(f.get('title')).trim(), p_description: String(f.get('description')).trim(),
                p_media_path: null, p_goal: f.get('goal'), p_budget: Number(f.get('budget'))
              });
              if (r.error) throw r.error;
              toast('Campagne créée. Elle sera vérifiée par l’administration.');
              render();
            });
          };
          app.querySelectorAll('[data-pause]').forEach(function (b) {
            b.onclick = function () {
              guard(b, async function () {
                const r = await sb.rpc('pause_campaign', { p_campaign: b.dataset.pause });
                if (r.error) throw r.error;
                render();
              });
            };
          });
        }
      };
    },

    alerts: alerts
  };

  /* ---------- Espace diffuseur ---------- */
  const brTabs = {
    home: async function () {
      const b = await balances('broadcaster');
      const w = await sb.from('withdrawals').select('amount,status').eq('user_id', user.id).eq('status', 'paid');
      const paid = (w.data || []).reduce(function (a, x) { return a + Number(x.amount); }, 0);
      return {
        html: '<h1>Bonjour ' + esc((profile.full_name || '').split(' ')[0]) + '</h1>' +
          '<div class="card"><div class="muted small">Solde disponible pour un retrait</div><div class="kpi">' + fcfa(b.available) + '</div></div>' +
          '<div class="grid2"><div class="card"><div class="muted small">Gains en attente de validation</div><div class="kpi">' + fcfa(b.pending) + '</div></div>' +
          '<div class="card"><div class="muted small">Retraits en attente</div><div class="kpi">' + fcfa(b.withdrawing) + '</div></div></div>' +
          '<div class="card"><div class="muted small">Retraits effectués</div><div class="kpi">' + fcfa(paid) + '</div></div>' +
          '<div class="actions"><button data-go="ads">Voir les publicités</button><button class="ghost" data-go="withdraw">Demander un retrait</button></div>',
        bind: function () { app.querySelectorAll('[data-go]').forEach(function (b) { b.onclick = function () { tab = b.dataset.go; render(); }; }); }
      };
    },

    ads: async function () {
      const c = await sb.from('campaigns').select('id,title,description,goal,reward_per_result,target_results,results_validated').eq('status', 'active').order('created_at', { ascending: false });
      if (c.error) throw c.error;
      return {
        html: '<h1>Publicités disponibles</h1>' +
          '<p class="note">Les gains sont crédités uniquement après validation de votre preuve. Une capture d’écran est un indice de diffusion, pas une preuve absolue de vues.</p>' +
          list(c.data.map(function (x) {
            return '<div class="item"><div class="row"><b>' + esc(x.title) + '</b><span class="badge ok">' + fcfa(x.reward_per_result) + ' / ' + (x.goal === 'views' ? 'vue' : 'clic') + '</span></div>' +
              '<div class="small" style="margin-top:4px">' + esc(x.description) + '</div>' +
              '<div class="muted small">' + (x.target_results - x.results_validated) + ' résultats restants</div></div>';
          }), 'Aucune publicité disponible pour le moment.') +
          '<p class="muted small">Le partage et l’envoi de preuve seront ajoutés à l’étape suivante.</p>'
      };
    },

    withdraw: async function () {
      const b = await balances('broadcaster');
      const w = await sb.from('withdrawals').select('*').eq('user_id', user.id).order('created_at', { ascending: false }).limit(30);
      if (w.error) throw w.error;
      const min = Number(S.min_withdrawal);
      const ok = b.available >= min;
      return {
        html: '<h1>Retrait</h1>' +
          '<div class="card"><div class="muted small">Solde disponible</div><div class="kpi">' + fcfa(b.available) + '</div>' +
          '<div class="muted small">Retrait minimum : ' + fcfa(min) + '. Seuls les gains validés sont retirables.</div></div>' +
          '<form id="wf" class="card stack">' +
          '<div><label>Montant (FCFA)</label><input name="amount" type="number" min="' + min + '" max="' + b.available + '" step="1" required' + (ok ? '' : ' disabled') + '></div>' +
          '<div><label>Numéro de réception mobile money</label><input name="phone" type="tel" value="' + esc(profile.phone) + '" required' + (ok ? '' : ' disabled') + '></div>' +
          '<button class="full" type="submit"' + (ok ? '' : ' disabled') + '>Confirmer la demande</button>' +
          (ok ? '' : '<p class="muted small">Votre solde n’atteint pas encore le minimum de retrait.</p>') + '</form>' +
          '<h2>Mes demandes</h2>' +
          list(w.data.map(function (x) {
            return '<div class="item"><div class="row"><b>' + fcfa(x.amount) + '</b>' + badge(x.status) + '</div><div class="muted small">' + fdate(x.created_at) +
              (x.payout_reference ? ' · Réf. ' + esc(x.payout_reference) : '') + '</div>' +
              (x.status === 'rejected' && x.reject_reason ? '<div class="small">Motif : ' + esc(x.reject_reason) + '</div>' : '') + '</div>';
          }), 'Aucune demande de retrait.'),
        bind: function () {
          const f = $('#wf');
          f.onsubmit = function (ev) {
            ev.preventDefault();
            const fd = new FormData(f);
            guard(f.querySelector('button'), async function () {
              const r = await sb.rpc('request_withdrawal', { p_amount: Number(fd.get('amount')), p_phone: String(fd.get('phone')).trim() });
              if (r.error) throw r.error;
              toast('Demande envoyée.');
              render();
            });
          };
        }
      };
    },

    alerts: alerts
  };

  async function alerts() {
    const n = await sb.from('notifications').select('*').eq('user_id', user.id).order('created_at', { ascending: false }).limit(40);
    if (n.error) throw n.error;
    const unread = n.data.some(function (x) { return !x.read; });
    return {
      html: '<h1>Alertes</h1>' + list(n.data.map(function (x) {
        return '<div class="item"><div class="row"><b>' + esc(x.title) + '</b>' + (x.read ? '' : '<span class="badge">Nouveau</span>') + '</div>' +
          '<div class="small">' + esc(x.body) + '</div><div class="muted small">' + fdate(x.created_at) + '</div></div>';
      }), 'Aucune alerte.'),
      bind: function () {
        if (unread) sb.from('notifications').update({ read: true }).eq('user_id', user.id).eq('read', false).then(function () {});
      }
    };
  }

  boot();
})();
